﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Projeto_3_camadas_BLL_DAL_DTO.Code.BLL
{
    class MedicamentoBLL
    {
        public void Inserir (DTO.MedicamentoDTO meddto)
        {

        }
    }
}
